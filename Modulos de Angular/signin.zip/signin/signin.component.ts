import { Component } from '@angular/core';
import { AuthService } from '../../services/auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent {

  user = {
    email: '',
    password: ''
  }
  loginPanel: string;
  registerPanel: string;

  constructor(
      private authService: AuthService,
      private router: Router
    ){}

  ngOnInit(){}

  display_register(){
    document.getElementById("loginModal").style.display = "none";
    document.getElementById("registerForm").style.display = "flex";
  }
  display_login(){
    document.getElementById("registerForm").style.display = "none";
    document.getElementById("loginModal").style.display = "flex";
  }

  trigger_anim() {
    document.getElementById("register_btn_text").style.display = "none";
    document.getElementById("register_btn_anim").style.display = "flex";

  }
  show_repeteaded_password() {
    var x = document.getElementById("password-confirm") as HTMLInputElement;
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
  }

  show_password() {
    var x = document.getElementsByClassName("password-register")[0] as HTMLInputElement;
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
  }
// Register Form Validator
validateEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
  }

password_validator() {

    var password = document.getElementsByClassName("password-register")[0] as HTMLInputElement;
    var email = document.getElementsByName("email")[1] as HTMLInputElement;
    var password_repeated = document.getElementById("password-confirm") as HTMLInputElement;
    var terms_switch = document.getElementById("terms_switch") as HTMLInputElement;
    var user_register_btn = document.getElementById("user_register_btn") as HTMLInputElement;

    document.getElementById('password_unmatched_err').style.display="none";
    document.getElementById('email_empty_err').style.display="none";
    document.getElementById('password_empty_err').style.display="none";
    document.getElementById('password_too_short_err').style.display="none";
    document.getElementById('accept_terms').style.display="none";
    document.getElementById('email_invalid_err_front').style.display="none";
    try {
        document.getElementById('email_invalid_err').style.display="none";
    } catch (error) {}
        
    if(email.value != ''){
        if(this.validateEmail(email.value)){
            if(password.value != '' || password_repeated.value != ''){
                if (password.value === password_repeated.value) {
                    if(password.value.length >= 6){
                        password.style.border = "2px solid green";
                        password_repeated.style.border = "2px solid green";
                        if(terms_switch.checked){
                            user_register_btn.disabled = false;
                        }else{
                            user_register_btn.disabled = true;
                            document.getElementById("accept_terms").style.display="block";
                        }
                    }else{
                        document.getElementById('password_too_short_err').style.display="block";
                        user_register_btn.disabled = true;
                    }
                }else{
                    password.style.border = "2px solid red";
                    password_repeated.style.border = "2px solid red";
                    user_register_btn.disabled = true;
                    document.getElementById("password_unmatched_err").style.display="block";
                }
            }else{
                document.getElementById('password_empty_err').style.display="block";
                user_register_btn.disabled = true;
            }
        }else{
            document.getElementById('email_invalid_err_front').style.display="block";
            user_register_btn.disabled = true;
        }
    }else{
        document.getElementById('email_empty_err').style.display="block";
        user_register_btn.disabled = true;
    }
}

show_login_password() {
    var x = document.getElementsByClassName("login_password")[0] as HTMLInputElement;
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
  signIn(){
    this.authService.signIn(this.user)
    .subscribe(
      res => {
        localStorage.setItem('token', res.token);
        this.router.navigate(['/dashboard']);
      },
      err => {console.log(err)}
    )
  }

  signUp(){
    this.authService.signUp(this.user)
    .subscribe(
      res => {
        localStorage.setItem('token', res.token);
        this.router.navigate(['/dashboard']);
      },
      err => {console.log(err)}
    )
  }
}
